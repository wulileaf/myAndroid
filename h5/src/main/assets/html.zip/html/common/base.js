// ios
var IS_IOS = 0;
if (navigator.userAgent.indexOf("iPhone") != -1) {
    IS_IOS = 1;
}
if (navigator.userAgent.indexOf("iPad") != -1) {
    IS_IOS = 1;
}

function getHeight() {
    if (IS_IOS == 1) {
        return 64;
    } else {
        return 44;
    }
}